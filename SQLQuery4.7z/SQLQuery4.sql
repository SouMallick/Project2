create table New_Products
(Product_Id int primary key,
Product_Type varchar(100),
Product_Name varchar(100),
Product_Description varchar(100),
Price money,
Stock int,
Category int foreign key references Category(Id) )



select * from New_Products

create table Category
(
 Id int identity(1,1) primary key,
 Name varchar(20) unique not null
)

select * from Category

insert into Category values('Electronics'),('Clothing'),('Accessories'),('Groceries')

